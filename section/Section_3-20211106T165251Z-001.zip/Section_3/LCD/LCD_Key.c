/*
 * LCD_Key.c
 *
 * Created: 11/2/2021 12:48:03 AM
 * Author: Muhammad Hassan
 */

#include <mega16.h>
#include <alcd.h>
#include <delay.h>

void main(void)
{

unsigned char x = 0;
lcd_init(16);       // Don't forget

while (1)
    {
    // Please write your application code here  
    
     lcd_printf("#people = %u",x++);
     delay_ms(1000);
     lcd_clear();
    
    
    lcd_puts("Hello");
    lcd_puts(" AVR!");
    delay_ms(1000);
    lcd_clear();
    
    lcd_gotoxy(0,1);
    lcd_puts("Section 3!");
    delay_ms(1000);
    lcd_clear();
    

    }
}
